create definer = admin@`%` view openPricesView as
select row_number() OVER (ORDER BY `trades`.`openingPrices`.`date` ) AS `rowNum`,
       `trades`.`openingPrices`.`date`                               AS `date`,
       `trades`.`openingPrices`.`open`                               AS `open`,
       `trades`.`openingPrices`.`company`                            AS `company`
from `trades`.`openingPrices`;

