create definer = admin@`%` trigger createAction
    after insert
    on predictions
    for each row
begin
        declare boostedPred float;
#         declare currentOpenPrice float;
        set boostedPred=NEW.modelPredicted-(select avg(residual) from predictions order by date desc limit 181);
#         set currentOpenPrice=select open from openingPrices order by date desc limit 1
        insert into actions (date, company, boostedPrediction, action)
        values (
            NEW.date,
            NEW.company,
            boostedPred,
            IF(boostedPred - (select open from openingPrices order by date desc limit 1) > 0, 'buy','sell')
            );
    end;

