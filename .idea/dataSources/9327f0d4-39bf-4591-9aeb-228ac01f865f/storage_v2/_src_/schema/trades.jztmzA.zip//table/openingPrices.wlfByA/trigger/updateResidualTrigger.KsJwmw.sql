create definer = admin@`%` trigger updateResidualTrigger
    after insert
    on openingPrices
    for each row
begin
        declare modelPredictedTemp float;
        set modelPredictedTemp = (select modelPredicted from predictions where date=new.date);
        update predictions set residual=new.open-modelPredictedTemp where date=new.date;
    end;

