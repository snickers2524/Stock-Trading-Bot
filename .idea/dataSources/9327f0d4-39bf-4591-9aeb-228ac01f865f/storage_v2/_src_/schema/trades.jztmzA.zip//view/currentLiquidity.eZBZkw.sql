create view currentLiquidity as
select ((1000 - `buy`.`buyValue`) + `sell`.`sellValue`) AS `1000 - buyValue + sellValue`
from ((select sum((`trades`.`buyTrades`.`numShares` * `trades`.`buyTrades`.`buyPrice`)) AS `buyValue` from `trades`.`buyTrades`) `buy`
         join (select sum((`trades`.`sellTrades`.`numShares` * `trades`.`sellTrades`.`sellPrice`)) AS `sellValue` from `trades`.`sellTrades`) `sell`);

