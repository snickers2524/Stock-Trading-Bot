create definer = admin@`%` view currentShares as
select `buy`.`company` AS `company`, (`buy`.`numShares` - `sell`.`numShares`) AS `numShares`
from (`trades`.`buyTrades` `buy`
         join (select `trades`.`sellTrades`.`numShares` AS `numShares`, `trades`.`sellTrades`.`company` AS `company` from `trades`.`sellTrades`) `sell` on ((`buy`.`company` = `sell`.`company`)));

